package packagee;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Observable;
import java.util.Observer;

import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.GroupLayout;

import java.awt.Color;
public class Cliente1 extends javax.swing.JFrame implements Observer {
private static final long serialVersionUID = 1L;

public Cliente1() {
		getContentPane().setBackground(Color.PINK);
        initComponents();
        this.getRootPane().setDefaultButton(this.btnEnviar);
        Servidor s = new Servidor(7000);
        s.addObserver(this);
        Thread t = new Thread(s);
        t.start();
    }
    private void initComponents() {
        jScrollPane1 = new javax.swing.JScrollPane();
        txtTexto = new javax.swing.JTextArea();
        txtTexto.setBackground(new Color(255, 239, 213));
        txtTexto.setEditable(false);
        btnEnviar = new javax.swing.JButton();
        btnEnviar.setBackground(new Color(255, 0, 255));
        txtTextoEnviar = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        setTitle("Cliente 1");

        txtTexto.setColumns(20);
        txtTexto.setRows(5);
        jScrollPane1.setViewportView(txtTexto);

        btnEnviar.setText("Enviar");
        btnEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarActionPerformed(evt);
                String Vaciar = "";
                txtTextoEnviar.setText(Vaciar);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(txtTextoEnviar, GroupLayout.DEFAULT_SIZE, 432, Short.MAX_VALUE)
        					.addGap(18)
        					.addComponent(btnEnviar, GroupLayout.PREFERRED_SIZE, 74, GroupLayout.PREFERRED_SIZE)
        					.addGap(40))
        				.addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 714, Short.MAX_VALUE))
        			.addContainerGap())
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 237, GroupLayout.PREFERRED_SIZE)
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(layout.createSequentialGroup()
        					.addGap(13)
        					.addComponent(txtTextoEnviar, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE))
        				.addGroup(layout.createSequentialGroup()
        					.addGap(31)
        					.addComponent(btnEnviar, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)))
        			.addGap(14))
        );
        getContentPane().setLayout(layout);

      
    }

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {
 String mensaje = "\n"+"1: " + this.txtTextoEnviar.getText() + "\n";
 this.txtTexto.append(mensaje);

        Calendar fecha = Calendar.getInstance();
        String dia, mes, a�o;
        dia = Integer.toString(fecha.get(Calendar.DATE));
        mes = Integer.toString(fecha.get(Calendar.MONTH));
        a�o = Integer.toString(fecha.get(Calendar.YEAR));
        this.txtTexto.append(dia+"/"+mes+"/"+a�o);
        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        System.out.println("Hora actual:"+dateFormat.format(date));
        
        Cliente c = new Cliente(7500, mensaje);
        Thread t = new Thread(c);
        t.start();
  }
 
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cliente1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cliente1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cliente1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cliente1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cliente1().setVisible(true);
            }
        });
    }
    private javax.swing.JButton btnEnviar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txtTexto;
    private javax.swing.JTextField txtTextoEnviar;
    	public void update(Observable o, Object arg) {
        this.txtTexto.append((String) arg);    }

}