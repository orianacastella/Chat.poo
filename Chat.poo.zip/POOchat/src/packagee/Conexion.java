package packagee;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion{
	static final String URL = "jdbc:postgresql://localhost:5433/postgres";
	static final String USER = "postgres";
	static final String PASS = "postgre";
	 
	public static Connection crearConexion() throws ClassNotFoundException, SQLException{
	Class.forName("org.postgresql.Driver");
	Connection conexion = DriverManager.getConnection(URL, USER, PASS);
	if (conexion != null){
	System.out.print("Conexion establecida con la base de datos");
	return conexion;
	}
	return null;
	}

	
	
	
}
